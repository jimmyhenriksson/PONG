#include <stdint.h>

uint8_t fontplayer1[];
uint8_t fontplayer2[];
uint8_t fontpaused[];

uint8_t fontopen[];
uint8_t fontpong[];

uint8_t fontlevelBas[];
uint8_t fontlevelAd[];
